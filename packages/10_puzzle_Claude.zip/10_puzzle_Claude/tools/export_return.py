#!/usr/bin/env python3
import json, hashlib, zipfile, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];m=json.loads((root/'handoff.json').read_text());base=json.loads((root/'baseline.sha256.json').read_text());project=root/'project'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def allowed(s):return any(s.startswith(x) if x.endswith('/') else s==x for x in m['editable_paths'])
for rel,h in base.items():
 if not allowed(rel):
  p=project/rel
  if not p.is_file() or sha(p)!=h:raise SystemExit('Read-only shared dependency changed: '+rel+' — copy it into your own game folder instead.')
changes=[];files=[]
for p in sorted(project.rglob('*')):
 if p.is_symlink():raise SystemExit('Symlinks are not allowed')
 if not p.is_file():continue
 rel=p.relative_to(project).as_posix()
 if not allowed(rel):continue
 if any(x in p.parts for x in ('.git','.env','node_modules','.vercel')):raise SystemExit('Unexpected private file: '+rel)
 files.append((p,rel));h=sha(p)
 if base.get(rel)!=h:changes.append({'path':rel,'before_sha256':base.get(rel),'after_sha256':h})
removed=[r for r in base if allowed(r) and not (project/r).exists()]
report={'game':m['id'],'source_commit':m['source_commit'],'changes':changes,'removed':removed,'production_authorized':False,'note':'Human review and integration tests are mandatory. This tool never uploads or deploys.'}
out=root/(m['id']+'-RETURN-FOR-REVIEW.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,r in files:z.write(p,'candidate/'+r)
 z.writestr('CHANGES.json',json.dumps(report,ensure_ascii=False,indent=2))
 z.write(root/'handoff.json','handoff.json')
 for name in ('CHANGELOG.md','TEST_RESULTS.md','ASSET_LICENSES.md','KNOWN_ISSUES.md'):
  if (root/name).exists():z.write(root/name,name)
print('Created',out.name,'with',len(files),'candidate files;',len(changes),'changed and',len(removed),'removed. No deployment performed.')
