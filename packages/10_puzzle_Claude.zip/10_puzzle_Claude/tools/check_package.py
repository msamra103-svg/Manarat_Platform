#!/usr/bin/env python3
import json,hashlib,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];m=json.loads((root/'handoff.json').read_text());b=json.loads((root/'baseline.sha256.json').read_text());fail=[]
for r,h in b.items():
 editable=any(r.startswith(x) if x.endswith('/') else r==x for x in m['editable_paths'])
 p=root/'project'/r
 if not editable and (not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=h):fail.append(r)
if fail:raise SystemExit('Read-only files changed: '+', '.join(fail))
print('PASS: shared dependencies unchanged; editable scope:',', '.join(m['editable_paths']))
