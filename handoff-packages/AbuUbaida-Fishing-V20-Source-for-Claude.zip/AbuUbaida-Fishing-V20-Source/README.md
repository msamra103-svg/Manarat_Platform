# Fishing game source handoff — مدرسة أبو عبيدة الإعدادية للبنين
This is the **original game source**, not an upgraded build. Pinned to original repository commit: f9b54bd1beaf869ff4d3ea6e2e72926025bc16b4
Source repository: https://github.com/msamra103-svg/Manarat_Platform
Entry point: games/fishing/index.html
Includes local renderer games/vendor/three.min.js, original shared 3D scene/game/motion, CSS, athlete rig, navigation JS, cover and current tests.
IMPORTANT: games/experiences shared files run volleyball/puzzle/classic too. Claude MUST split fishing-specific upgrades into new files under games/fishing/ and never replace shared runtime files in production.
The reference-only/platform/js/ directory is read-only context for parent iframe contract/teacher editor; DO NOT deploy these copies.
To run: node scripts/serve.cjs then http://127.0.0.1:4173/games/fishing/index.html.
Run baseline tests: npm run test:baseline.
Complete instructions for Claude: CLAUDE_FULL_DEVELOPMENT_PROMPT.md
