# Current platform iframe message contract (read-only)
Hosted iframe id: fishingGame, src: games/fishing/index.html, at same origin.
Game emits: school-fishing-ready / question / outcome / next / fullscreen.
Host emits: school-fishing-config {title,count,images,token}; school-fishing-result {token,index,correct,pending,feedback}; school-fishing-advance {token,index:previousIndex}; school-fishing-retry {token,index}.
The host checks e.origin===location.origin, e.source===frame.contentWindow, token and current question index.
GAME MUST verify parent origin/source, token, index. Teacher questions and grading come from the host and school-api, not the iframe.
Source evidence: reference-only/platform/js/school.js. This file is for CONTRACT REFERENCE ONLY.
